var $socket = io.connect('https://multilingual-chat.herokuapp.com/');

var $nickname;
var $room;
var $language;
//TODO
//ADD VARIABLES $recognition, $transcript, $recognizing
var $recognition;
var $transcript;
var $recognizing;

//ON ADMIN MESSAGE RECEIVED
$socket.on('adminMessage', function (messages) {
    //TODO
    //RETRIEVE THE CORRECT LANGUAGE MESSAGE
    var li = jQuery('<li class="left"></li>');
    li.text('Admin : '+messages[$language]);

    //DISPLAY IT
    $('#messages').append(li);
});

//ON NEW MESSAGE RECEIVED
$socket.on('newMessage', function (messages, from) {
    var li;

    //TODO
    //TEST IF OWN MESSAGE
    if(from != $nickname)
        li = jQuery('<li class="left"></li>');
    else
        li = jQuery('<li class="right"></li>');

    //RETRIEVE THE CORRECT LANGUAGE MESSAGE
    li.text(from+' : '+messages[$language]);

    //DISPLAY IT
    $('#messages').append(li);

});

//ON LEFT MESSAGE RECEIVED
$socket.on('leftMessage', function (messages) {
    //TODO
    //RETRIEVE THE CORRECT LANGUAGE MESSAGE
    var li = jQuery('<li class="right red"></li>');
    li.text('Admin : '+messages[$language]);

    //DISPLAY IT
    $('#messages').append(li);
});
//ON JOIN MESSAGE RECEIVED
$socket.on('joinMessage', function (messages) {
    //TODO
    //RETRIEVE THE CORRECT LANGUAGE MESSAGE
    var li = jQuery('<li class="right green"></li>');
    li.text('Admin : '+messages[$language]);

    //DISPLAY IT
    $('#messages').append(li);
});
//ON UPDATE USERS LIST MESSAGE RECEIVED
$socket.on('updateUserList', function (users) {

    var usersList = jQuery('<ul></ul>');

    //TODO
    //LOOP IN USERS LIST & DISPLAY IT
    users.forEach(function (user)
    {
        usersList.append(jQuery('<li></li>').text(user.nickname));
    });

    $('#users').replaceWith(usersList);

});

$(document).ready(function ()
{
    //TODO
    //STORE THE URL VALUES
    var url = new URL(window.location.href);
    $nickname = url.searchParams.get('nickname');
    $room = url.searchParams.get('room');
    $language = url.searchParams.get('language');

    //TODO
    //JOIN THE ROOM
    $socket.emit('join',$nickname, $room, $language);
})

//SEND MESSAGE METHOD
function sendMessage()
{
    //TODO
    //Test if webkitSpeechRecogntion is available in the current browser
    //else confirm message : Your browser doesn't support Web Speech API. Please try it with Google Chrome
    //and redirect to login

}

//CONFIGURE RECOGNITION
function configureRecording()
{
    //TODO
    //Initialise $recognition = new webkitSpeechRecognition()
    //Set the language of the $recognition
    //Disable $recognition continuous config
    //Enable  $recognition intermediate results


    //TODO
    //Set $recognizing variable to true when recording


    //TODO
    //Set $recognizing variable to false when stop recording


    //TODO
    //Set $recognizing variable to false when error occured


    //TODO
    //Set $recognition onresult function

    {
        //TODO
        //Empty input value


        //TODO
        //Loop for each result

        {
            //TODO
            //Retrieve actual transcript of recording


            //TODO
            //Test if final result of recording

            {
                //TODO
                //Set the input value
                //Stop the recording


                //TODO
                //Test if there is an actual transcript



            }
            //else
            {
                //TODO
                //Set interim results

            }

        }
    }
}

//START RECOGNITION
function startRecognition()
{
    $recognition.start();
    $recognizing = true;
    $('#record-button').addClass('red-background');
}

//STOP RECOGNITION
function stopRecognition()
{
    $recognition.stop();
    $recognizing = false;
    $('#record-button').removeClass('red-background');
}