var $socket = io.connect('https://multilingual-chat.herokuapp.com/');

var $nickname;
var $room;
var $language;

//ON ADMIN MESSAGE RECEIVED
$socket.on('adminMessage', function (messages) {
    //TODO
    //RETRIEVE THE CORRECT LANGUAGE MESSAGE


    //DISPLAY IT

});

//ON NEW MESSAGE RECEIVED
$socket.on('newMessage', function (messages, from) {
    var li;

    //TODO
    //TEST IF OWN MESSAGE
    //if use class="left"
    //else use class="right"


    //RETRIEVE THE CORRECT LANGUAGE MESSAGE


    //DISPLAY IT


});

//ON LEFT MESSAGE RECEIVED
$socket.on('leftMessage', function (messages) {
    //TODO
    //RETRIEVE THE CORRECT LANGUAGE MESSAGE


    //DISPLAY IT

});

//ON JOIN MESSAGE RECEIVED
$socket.on('joinMessage', function (messages) {
    //TODO
    //RETRIEVE THE CORRECT LANGUAGE MESSAGE


    //DISPLAY IT

});

//ON UPDATE USERS LIST MESSAGE RECEIVED
$socket.on('updateUserList', function (users) {

    var usersList = jQuery('<ul></ul>');

    //TODO
    //LOOP IN USERS LIST & DISPLAY IT


    $('#users').replaceWith(usersList);

});

$(document).ready(function ()
{
    //TODO
    //STORE THE URL VALUES
    var url
    $nickname
    $room
    $language

    //TODO
    //JOIN THE ROOM
    //PARAMS : methodName, nickname, room, language

})

//SEND MESSAGE METHOD
function sendMessage()
{
    //TODO
    //STORE MESSAGE VALUE
    var $message

    //RESET MESSAGE INPUT

    //SEND MESSAGE TO SOCKET :
    //PARAMS : methodName, nickname, room, language, message
}